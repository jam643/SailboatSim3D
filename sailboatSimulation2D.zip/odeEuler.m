function [t,zarray]=odeEuler(fhandle,tspan,z0,ptemp)
%%% allows for user to have active control of sail and rudder
 
%creates global parameters to be used in subfunctions
global p;
p=ptemp;

%Initialize figure object
f=figure(1);
cla
set(f,'units','normalized','outerposition',[0 0 1 1],'color',[.5,.8,1]);
set(f,'WindowKeyPressFcn',@KeyPress,'WindowKeyReleaseFcn',@KeyRelease);
 
 
%Bar scale for up/down arrow key input
subplot(2,20,20)
barLim_rudder = [-90 90];   %Bar scale
bar_rudder = bar(0);     %Initialize the bar in the middle of the scale
ylim(barLim_rudder);       %Set upper limit
xlabel('Up/Down Arrow');
set(gca, 'XTick', []);
title('Rudder Angle','fontweight','bold');

if p.active==3
    %control both sail and rudder
    %Bar scale for up/down arrow key input
    subplot(2,20,40)
    barLim_sail = [-90 90];   %Bar scale
    bar_sail = bar(0);     %Initialize the bar in the middle of the scale
    ylim(barLim_sail);       %Set upper limit
    xlabel('Left/Right Arrow');
    set(gca, 'XTick', []);
    title('Sail Angle','fontweight','bold');
end

%Main plot area
subplot(2,20,[1:19,21:39],'color',[.5,.8,1])
p.d=max(abs([p.d_sail,p.d_keel,p.d_rudder]));
if p.d==0
    p.d=1;
end

t=0;
zarray=z0';

%axis limits
p.limx=[zarray(1,1)-4*p.d,zarray(1,1)+4*p.d];
p.limy=[zarray(1,1)-3*p.d,zarray(1,1)+3*p.d];

hold on
axis equal

%wind vector
annotation('textarrow',[.1,.1+.05*p.v_a(1)/norm(p.v_a)],...
    [0.5,0.5+.05*p.v_a(2)/norm(p.v_a)],'string',sprintf('Velocity_{air}=%dm/s',p.v_airMag),...
    'fontsize',12,'linewidth',3);
 
%Sensitivity of arrow keys. Adjust this as desired.
keyspeed_rudder = 0.8;
keyspeed_sail=0.8;
 
%Initialize the arrow keys as not being pressed
commands.up = false;
commands.down = false;
commands.left = false;
commands.right = false;
set(f,'UserData',commands); %Store these commands in the figure object

numInt=5; %number of times to perform Euler integration per step (increase if solution explodes)
 
%Continuously update until the user closes the figure window
tic

while(ishandle(f)) && t(end)<tspan(2)
    
    %extract sail and rudder angles from bar plot
    bar2val_rudder = get(bar_rudder,'ydata');
    p.angle_rRelb = pi*bar2val_rudder/180;
    p.angle_rRels=p.angle_rRelb;
    if p.active==3
        bar2val_sail=get(bar_sail,'ydata');
        p.angle_sRelb=pi*bar2val_sail/180;
    end
    t(end+1)=toc;
    dt=t(end)-t(end-1);
    z=zarray(end,:)';
    
    %integrates using Eulers method
    for k=1:numInt
        zdot=feval(fhandle,t,z,p);
        z=z+(1/numInt)*dt*zdot;
    end
    zarray(end+1,:)=z';
    
    %animation
    p=animateRT(t(end),zarray,p);
    
    %%%% GRAPHICS UPDATE HERE %%%%
   %Get input from the keyboard
   commands = get(f,'UserData') ;
   
   %Adjust the bar position if the user has given input
   if (commands.up && bar2val_rudder<=barLim_rudder(2))
       set(bar_rudder,'ydata',bar2val_rudder + keyspeed_rudder);
   elseif (commands.down && bar2val_rudder >=barLim_rudder(1))
       set(bar_rudder,'ydata',bar2val_rudder - keyspeed_rudder);
   elseif p.active==3 && (commands.right && bar2val_sail <= barLim_sail(2))
       set(bar_sail,'ydata',bar2val_sail + keyspeed_sail);
   elseif p.active==3 && (commands.left && bar2val_sail >= barLim_sail(1))
       set(bar_sail,'ydata',bar2val_sail - keyspeed_rudder);
   end
   
   %Pause the program for a tiny amount of time. This is necessary to make
   %it work.
   pause(0.01);
end

plotBoatData(zarray,t);

%%%%%%%%%%% KEYBOARD CALLBACKS %%%%%%%%%%% 
function KeyPress(varargin)
    %This function is continuously running and checking the keyboard input.
    %It takes in varargin, which stands for variable argument input. 
     fig = varargin{1};
     key = varargin{2}.Key;
     %Change 'UserData' part of the figure object depending on the input.
     if strcmp(key,'uparrow')
         x=get(fig,'UserData'); %Get the UserData
         x.up = true;           %Update the command
         set(fig,'UserData',x); %Put the new UserData back into the object
     elseif strcmp(key,'downarrow')
         x=get(fig,'UserData');
         x.down = true;
         set(fig,'UserData',x);
     elseif p.active==3 && strcmp(key,'rightarrow')
         x=get(fig,'UserData');
         x.right=true;
         set(fig,'UserData',x);
     elseif p.active==3 && strcmp(key,'leftarrow')
         x=get(fig,'UserData');
         x.left=true;
         set(fig,'UserData',x);
     end
end
function KeyRelease(varargin)
    %This function is the same as KeyPress, except it resets the command
    %when the user releases the up/down arrow.
     fig = varargin{1};
     key = varargin{2}.Key;
     if strcmp(key,'uparrow')
         x=get(fig,'UserData');
         x.up = false;
         set(fig,'UserData',x);
     elseif strcmp(key,'downarrow')
         x=get(fig,'UserData');
         x.down = false;
         set(fig,'UserData',x);
     elseif p.active==3 && strcmp(key,'rightarrow')
         x=get(fig,'UserData');
         x.right = false;
         set(fig,'UserData',x);
     elseif p.active==3 && strcmp(key,'leftarrow')
         x=get(fig,'UserData');
         x.left = false;
         set(fig,'UserData',x)
     end
end
 
end