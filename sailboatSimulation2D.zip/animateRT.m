function p=animateRT(t,zarray,p)
%%%Animate boat's motion in real time

%Animation
d=p.d; ds=p.d_sail; dk=p.d_keel; dr=p.d_rudder; limx=p.limx; limy=p.limy;

%extract variables
theta=zarray(end,3);
xG=zarray(end,1);
yG=zarray(end,2);
v_boat=zarray(end,4:5);
omega=zarray(end,6);

%plot trajectory so far
cla;
ht=plot(zarray(1:end,1),zarray(1:end,2),'k','linewidth',2);
hold on

%plot > rotate > translate hull
xh=[-d,0,d,0,-d,-d];
yh=[-.1*d,-.2*d,0,.2*d,.1*d,-.1*d];
xhp=xh*cos(theta)-yh*sin(theta)+xG;
yhp=xh*sin(theta)+yh*cos(theta)+yG;
hb=fill(xhp,yhp,'k');

%plot > rotate > translate keel
xk=[-.5*d,.5*d]+dk;
yk=[0,0];
xkp=xk*cos(theta)-yk*sin(theta)+xG;
ykp=xk*sin(theta)+yk*cos(theta)+yG;
hk=plot(xkp,ykp,'b','linewidth',5);

%plot > rotate > translate sail
xs=[-.5*d,.5*d];
ys=[0,0];
%sail velocity relative to air
v_sail=v_boat+p.d_sail*omega*[-sin(theta),cos(theta)]-p.v_a;
if p.sailType==1
    alpha_sail=p.angle_sRelw;
    p.angle_sRelb=wrapTo2Pi(alpha_sail+atan2(v_sail(2),v_sail(1))-theta);
    theta_sail=alpha_sail+atan2(v_sail(2),v_sail(1));
elseif p.sailType==2   
    %determines if angle of attack should be +5 or -5 deg.
    if (wrapTo2Pi(atan2(v_sail(2),v_sail(1))-theta)) < pi
        alpha_sail=2*pi-p.angle_sRelw;
    else
        alpha_sail=p.angle_sRelw;
    end
    p.angle_sRelb=wrapTo2Pi(alpha_sail+atan2(v_sail(2),v_sail(1))-theta);
    theta_sail=alpha_sail+atan2(v_sail(2),v_sail(1));
else
    theta_sail=theta+p.angle_sRelb;
end
xsp=xs*cos(theta_sail)-ys*sin(theta_sail)+xG+ds*cos(theta);
ysp=xs*sin(theta_sail)+ys*cos(theta_sail)+yG+ds*sin(theta);
hs=plot(xsp,ysp,'g','linewidth',5);

if p.rudderType<3
    %plot > rotate > translate rudder
    xr=[-.2*d,.2*d];
    yr=[0,0];
    theta_rudder=theta+p.angle_rRelb;
    xrp=xr*cos(theta_rudder)-yr*sin(theta_rudder)+xG+dr*cos(theta);
    yrp=xr*sin(theta_rudder)+yr*cos(theta_rudder)+yG+dr*sin(theta);
    hr=plot(xrp,yrp,'r','linewidth',5);
elseif p.rudderType==3
    xr=[-.2*d,.2*d];
    yr=[0,0];
    theta_rudder=theta+p.angle_rRels+p.angle_sRelb;
    xrp=xr*cos(theta_rudder)-yr*sin(theta_rudder);
    xrp=xrp+xG+p.d_rRels*cos(theta+p.angle_sRelb)+p.d_sail*cos(theta);
    yrp=xr*sin(theta_rudder)+yr*cos(theta_rudder);
    yrp=yrp+yG+p.d_rRels*sin(theta+p.angle_sRelb)+p.d_sail*sin(theta);
    hr=plot(xrp,yrp,'r','linewidth',5);
end

v_appWind=p.v_a-v_boat;
xa=v_appWind(1)*[0,0.3*d/norm(v_appWind)]+mean(xsp);
ya=v_appWind(2)*[0,0.3*d/norm(v_appWind)]+mean(ysp);
ha=plot(xa,ya,'w','linewidth',2);

v_madeGood=dot(-v_boat,p.v_a/norm(p.v_a));

%set axis limits for boat centric frame
buff=1.3*d;
if (xG-buff)-limx(1)<0
    Lx=(xG-buff)-limx(1);
elseif (xG+buff)-limx(2)>0
    Lx=(xG+buff)-limx(2);
else
    Lx=0;
end
if (yG-buff)-limy(1)<0
    Ly=(yG-buff)-limy(1);
elseif (yG+buff)-limy(2)>0
    Ly=(yG+buff)-limy(2);
else
    Ly=0;
end
limx=limx+Lx; limy=limy+Ly;
p.limx=limx; p.limy=limy;
axis([limx,limy]);

%create textbox with information
grid on
text(limx(1),limy(2),sprintf('time=%0.0f sec\n\nV_{boat}=%0.2f m/s\n\nV_{apparentWind}=%0.2f m/s\n\nV_{madeGood}=%0.2f m/s\n\nAngle_{sail rel. boat}=%0.2f rad\n\nAngle_{rudder rel. boat}=%0.2f rad',...
     t,norm(v_boat),norm(v_appWind),v_madeGood,p.angle_sRelb,p.angle_rRelb),'fontsize',12,'color','w','verticalalignment','top','horizontalalignment','right');