function plotBoatData(zarray,t)
%%%plot relevant boat data

figure(2);
plot(t,sqrt(zarray(:,4).^2+zarray(:,5).^2),'linewidth',2);
hold on;
xlabel('time [s]','fontsize',16);
ylabel('boat velocity magnitude','fontsize',16);

figure(3);
plot(t,zarray(:,6),'linewidth',2);
hold on;
xlabel('time [s]','fontsize',16);
ylabel('Angular velocity','fontsize',16);

figure(4);
plot(t,wrapTo2Pi(zarray(:,3)),'linewidth',2);
hold on;
xlabel('time [s]','fontsize',16);
ylabel('Boat Heading Angle [rad]','fontsize',16);

figure(5);
plot(t,wrapTo2Pi(atan2(zarray(:,5),zarray(:,4))),'linewidth',2);
hold on;
xlabel('time [s]','fontsize',16);
ylabel('Boat Velocity Angle [rad]','fontsize',16);


figure(6);
h1=plot(zarray(:,1),zarray(:,2),'linewidth',2);
hold on;
h2=plot(zarray(1,1),zarray(1,2),'rs','markersize',5,'linewidth',2);
xlabel('x-position boat [m]','fontsize',16);
ylabel('y-position boat [m]','fontsize',16);
h=legend([h1,h2],'Trajectory','Start');
set(h,'fontsize',14,'location','best');
axis equal;
