function [p,z0]=setBoatParam
%%%initializes various boat parameters in p structure

%initial conditions
x0=0; y0=0; th0=1; xdot0=0; ydot0=0; thdot0=0; %initial pose and (d/dt)pose
z0=[x0,y0,th0,xdot0,ydot0,thdot0]';

%simulation fps and run time
p.time=30;
p.fps=10;
p.view=1;
p.tspan=linspace(0,p.time,p.fps*p.time); %timespan of simulation [s]

%%%p.accuracy defines the accuracy with which lift and drag coeff. are
%%%interpolated
%1: most accurate but slower (using pchip interpolation)
%2: less accurate but fastest (approx. Clift Cdrag as sinusoidal)
p.accuracy=1;      

%sail
p.d_sail=0; %distance from C.O.M. to sail [m] (positive is infront COM)
p.SA_sail=.2; %surface area sail [m^2]
p.angle_sRelb=0.7; %angle of sail relative to boat [rad]
p.angle_sRelw=0.09;
p.sailType=3; %1: Free with fixed angle of attack relative to wind
              %2: Free with +/- fixed angle of attack relative to wind
              %3: Fixed angle rel. boat
%keel
p.d_keel=0; %distance from C.O.M. to keel [m] (positive is infront of COM)
p.SA_keel=0.1; %surface area keel [m^2]

%rudder
p.d_rudder=-0.5; %distance from C.O.M. to rudder [m] (positive is infront COM)
p.d_rRels=-0.5; %distance from sail center to rudder [m] (positive is infront of sail)
p.SA_rudder=0.05; %surface area rudder [m^2]
p.angle_rRelb=0*pi/180; %angle of rudder relative to boat [rad]
p.angle_rRels=0.5; %angle of rudder relative to sail [rad]
p.rudderType=3; %1: water rudder   2: air rudder    3: tail

p.v_airMag=-5; %magnitude of air velocity
p.v_airAngle=0; %direction of wind [rad]
p.v_a=p.v_airMag*[cos(p.v_airAngle),sin(p.v_airAngle)]; %x-y velocity componenets of air [m/s]
p.mass=7; %mass of boat [kg]
p.I=(1/12)*p.mass; %moment of inertia of boat about COM [kg*m^2]
p.rho_air=1.2; %density of air [kg/m^3]
p.rho_water=1000; %density of water [kg/m^3]

p.active=1; % 0: precalculate trajectory 1:active rudder control
            % 2: sail and rudder control

%%% Tabulated Data for NACA 0015 airfoil:
angle = [0,10,15,17,23,33,45,55,70,80,90,100,110,120,130,...
    140,150,160,170,180,190,200,210,220,230,240,250,260,...
    270,280,290,305,315,327,337,343,345,350,360]';

lift = [0,0.863,1.031,0.58,.575,.83,.962,.8579,.56,.327,...
    .074,-.184,-.427,-.63,-.813,-.898,-.704,-.58,-.813,0,...
    .813,.58,.704,.898,.813,.63,.427,.184,-.074,-.327,...
    -.56,-.8579,-.962,-.83,-.575,-.58,-1.031,-.863,0]';

drag = [0,.021,.058,.216,.338,.697,1.083,1.421,1.659,1.801,...
    1.838,1.758,1.636,1.504,1.26,.943,.604,.323,.133,0,...
    .133,.323,.604,.943,1.26,1.504,1.636,1.758,1.838,1.801,...
    1.659,1.421,1.083,.697,.338,.216,.058,.021,0]';

p.paraDrag=.15; %parasitic drag used to limit max(Cl/Cd)=5
drag=drag+p.paraDrag; %adjusted drag

p.C0=0.9;  % nominal lift coefficient for sinusoidal lift/drag approx.

%%% Fit a pchip piecewise-polynomial curve fit to the data
% This is good because it preserves local maximum and minimum
% Another option would be to replace pchip() with spline(), which would
% produce a more smooth curve, but would add new peaks to the data.
p.lift = pchip(angle,lift);
p.drag = pchip(angle,drag);
