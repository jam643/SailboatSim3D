function [R_hull,M_hull]=hullForce(v_boat,theta,omega,t,p)
%%%Calculates hull resistance and rotational damping

%hull resistance
R_hull=6.5*norm(v_boat)^2*(-v_boat);
%hull damping moment
M_hull=-2*omega;