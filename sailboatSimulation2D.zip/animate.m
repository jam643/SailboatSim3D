function animate(t,zarray,p)
%%% Animates boat's motion

%animation
f=figure(1);
clf
set(f,'units','normalized','outerposition',[0 0 1 1],'color',[.5,.8,1]);

%true wind vector
annotation('textarrow',[.1,.1+.05*p.v_a(1)/norm(p.v_a)],...
    [0.5,0.5+.05*p.v_a(2)/norm(p.v_a)],'string',sprintf('Velocity_{air}=%dm/s',p.v_airMag),...
    'fontsize',12,'linewidth',3);

%Animation
d=max(abs([p.d_sail,p.d_keel,p.d_rudder]));
if d==0
    d=1;
end
ds=p.d_sail; dk=p.d_keel; dr=p.d_rudder;

%initialize axis limits
limx=[zarray(1,1)-4*d,zarray(1,1)+4*d];
limy=[zarray(1,1)-3*d,zarray(1,1)+3*d];
axes('color',[.5,.8,1]);
hold on
axis equal

%for each instant in time
for m=1:length(t)
    if ~ishandle(f)
        break;
    end
    cla
    %extract values
    theta=zarray(m,3);
    x=zarray(m,1);
    y=zarray(m,2);
    v_boat=zarray(m,4:5);
    omega=zarray(m,6);
    
    %plot trajectory so far
    ht=plot(zarray(1:m,1),zarray(1:m,2),'k','linewidth',2);
    hold on
    
    %plot > rotate > translate hull
    xh=[-d,0,d,0,-d,-d];
    yh=[-.1*d,-.2*d,0,.2*d,.1*d,-.1*d];
    xhp=xh*cos(theta)-yh*sin(theta)+x;
    yhp=xh*sin(theta)+yh*cos(theta)+y;
    hb=fill(xhp,yhp,'k');
    
    %plot > rotate > translate keel
    xk=[-.5*d,.5*d]+dk;
    yk=[0,0];
    xkp=xk*cos(theta)-yk*sin(theta)+x;
    ykp=xk*sin(theta)+yk*cos(theta)+y;
    hk=plot(xkp,ykp,'b','linewidth',5);
    
    %plot > rotate > translate sail
    xs=[-.5*d,.5*d];
    ys=[0,0];
    %sail velocity relative to air
    v_sail=v_boat+p.d_sail*omega*[-sin(theta),cos(theta)]-p.v_a;
    if p.sailType==1
        %free sail with fixed angle of attack relative to wind
        alpha_sail=p.angle_sRelw;
        p.angle_sRelb=wrapTo2Pi(alpha_sail+atan2(v_sail(2),v_sail(1))-theta);
        theta_sail=alpha_sail+atan2(v_sail(2),v_sail(1));
    elseif p.sailType==2
        %free sail with +/- angle of attack relative to wind
        %determines if angle of attack should be + or - given angle
        if (wrapTo2Pi(atan2(v_sail(2),v_sail(1))-theta)) < pi
            alpha_sail=2*pi-p.angle_sRelw;
        else
            alpha_sail=p.angle_sRelw;
        end
        p.angle_sRelb=wrapTo2Pi(alpha_sail+atan2(v_sail(2),v_sail(1))-theta);
        theta_sail=alpha_sail+atan2(v_sail(2),v_sail(1));
    else
        %fixed sail
        theta_sail=theta+p.angle_sRelb;
    end
    xsp=xs*cos(theta_sail)-ys*sin(theta_sail)+x+ds*cos(theta);
    ysp=xs*sin(theta_sail)+ys*cos(theta_sail)+y+ds*sin(theta);
    hs=plot(xsp,ysp,'g','linewidth',5);
    
    if p.rudderType<3
        %plot > rotate > translate rudder
        xr=[-.2*d,.2*d];
        yr=[0,0];
        theta_rudder=theta+p.angle_rRelb;
        xrp=xr*cos(theta_rudder)-yr*sin(theta_rudder)+x+dr*cos(theta);
        yrp=xr*sin(theta_rudder)+yr*cos(theta_rudder)+y+dr*sin(theta);
        hr=plot(xrp,yrp,'r','linewidth',5);
    elseif p.rudderType==3
        xr=[-.2*d,.2*d];
        yr=[0,0];
        theta_rudder=theta+p.angle_rRels+p.angle_sRelb;
        xrp=xr*cos(theta_rudder)-yr*sin(theta_rudder);
        xrp=xrp+x+p.d_rRels*cos(theta+p.angle_sRelb)+p.d_sail*cos(theta);
        yrp=xr*sin(theta_rudder)+yr*cos(theta_rudder);
        yrp=yrp+y+p.d_rRels*sin(theta+p.angle_sRelb)+p.d_sail*sin(theta);
        hr=plot(xrp,yrp,'r','linewidth',5);
    end        
    
    v_appWind=p.v_a-v_boat;
    xa=v_appWind(1)*[0,0.3*d/norm(v_appWind)]+mean(xsp);
    ya=v_appWind(2)*[0,0.3*d/norm(v_appWind)]+mean(ysp);
    ha=plot(xa,ya,'w','linewidth',2);
    
    v_madeGood=dot(-v_boat,p.v_a/norm(p.v_a));
    
    if p.view==1
        %manage axes
        limx=[min(zarray(:,1))-2*d,max(zarray(:,1))+2*d]; 
        limy=[min(zarray(:,2))-2*d,max(zarray(:,2))+2*d];
        axis([limx,limy]);
        axis off
    else
        %set axis limits to be boat centric
        buff=1.3*d;
        if (x-buff)-limx(1)<0
            Lx=(x-buff)-limx(1);
        elseif (x+buff)-limx(2)>0
            Lx=(x+buff)-limx(2);
        else
            Lx=0;
        end
        if (y-buff)-limy(1)<0
            Ly=(y-buff)-limy(1);
        elseif (y+buff)-limy(2)>0
            Ly=(y+buff)-limy(2);
        else
            Ly=0;
        end
        limx=limx+Lx; limy=limy+Ly;
        axis([limx,limy]);
        grid on
    end
    text(limx(1),limy(2),sprintf('time=%0.0f sec\n\nV_{boat}=%0.2f m/s\n\nV_{apparentWind}=%0.2f m/s\n\nV_{madeGood}=%0.2f m/s',...
     t(m),norm(v_boat),norm(v_appWind),v_madeGood),'fontsize',12,'color','w','verticalalignment','top','horizontalalignment','right');
    pause(0.01)
end
if ishandle(f)
    h=legend([hb,hk,hs,hr,ht,ha],'Boat','Keel','Sail','Rudder','Trajectory','Apparent Wind');
    set(h,'location','best','fontsize',14,'color',[0.8,0.8,0.8]);
end

%create plots
plotBoatData(zarray,t);