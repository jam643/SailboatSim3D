function zdot=rhs(t,z,p)
%%%Heart of the simulation: calculates rate of change at every timestep
%%%based on AMB and LMB

theta=wrapTo2Pi(z(3)); %angle of boat heading relative to x-axis
v_boat=z(4:5)'; %2D vector of boat velocity
omega=z(6); %angular velocity of boat

%calculates forces on sail
if p.sailType==1
    %free sail
    [L_sail,D_sail,M_sail,p]=sailForce_free(v_boat,theta,omega,t,p);
elseif p.sailType==2
    %free sail with +/- angle of attack
    [L_sail,D_sail,M_sail]=sailForce_freePM(v_boat,theta,omega,t,p);
elseif p.sailType==3
    %fixed sail
    [L_sail,D_sail,M_sail]=sailForce_fixed(v_boat,theta,omega,t,p);
end

%calculates forces on keel
[L_keel,D_keel,M_keel]=keelForce(v_boat,theta,omega,t,p);

%calculates forces on rudder
if p.rudderType==1
    %water rudder
    [L_rudder,D_rudder,M_rudder]=rudderForce_water(v_boat,theta,omega,t,p);
elseif p.rudderType==2
    %ir rudder
    [L_rudder,D_rudder,M_rudder]=rudderForce_air(v_boat,theta,omega,t,p);
elseif p.rudderType==3
    %tail
    [L_rudder,D_rudder,M_rudder]=rudderForce_fixedOnSail(v_boat,theta,omega,t,p);
end

%calculate forces on hull
[R_hull,M_hull]=hullForce(v_boat,theta,omega,t,p);

%sum of forces
Ftot=L_sail+D_sail+L_keel+D_keel+L_rudder+D_rudder+R_hull;
%sum of moments
Mtot=M_rudder+M_keel+M_sail+M_hull;

%LMB
vdot=Ftot/p.mass;

%AMB
wdot=Mtot/p.I;

%rate of change
zdot=[z(4:6);vdot';wdot];

%update waitbar
if p.active==1
    h=gcf;
    waitbar(t/p.time,h);
end
