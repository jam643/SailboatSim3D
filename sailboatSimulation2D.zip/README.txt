sailSim

Description: 	
	sailSim simulates a sailboat in 2 dimensions. A GUI allows the user to select parameters and options.
	The results of the simulation are plotted and animated.

Usage:	
	Type sailsimGUI in the MATLAB command window to open the GUI. In the GUI, the user can select
	options and change various parameters before running the simulation by clicking the start button.

More Info:
	See sailboatStability.pdf for for more info on the dynamic model, simulation, and example results.

Credit:
	Jesse Miller
	jam643@cornell.edu