function varargout = sailsimGUI(varargin)
% SAILSIMGUI MATLAB code for sailsimGUI.fig
%      SAILSIMGUI, by itself, creates a new SAILSIMGUI or raises the existing
%      singleton*.
%
%      H = SAILSIMGUI returns the handle to a new SAILSIMGUI or the handle to
%      the existing singleton*.
%
%      SAILSIMGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SAILSIMGUI.MASS with the given input arguments.
%
%      SAILSIMGUI('Property','Value',...) creates a new SAILSIMGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before sailsimGUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to sailsimGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help sailsimGUI

% Last Modified by GUIDE v2.5 21-Apr-2015 12:10:46

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @sailsimGUI_OpeningFcn, ...
                   'gui_OutputFcn',  @sailsimGUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before sailsimGUI is made visible.
function sailsimGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to sailsimGUI (see VARARGIN)

% Choose default command line output for sailsimGUI
handles.output = hObject;
axis('off');
imshow('boatPic.jpg','Parent',handles.axes2);

global p; 

[p,z0]=setBoatParam;
set(handles.x0,'string',num2str(z0(1)));
set(handles.y0,'string',num2str(z0(2)));
set(handles.theta0,'string',num2str(z0(3)));
set(handles.xdot0,'string',num2str(z0(4)));
set(handles.ydot0,'string',num2str(z0(5)));
set(handles.thetadot0,'string',num2str(z0(6)));
set(handles.v_airMag,'string',num2str(p.v_airMag));
set(handles.v_airAngle,'string',num2str(p.v_airAngle));
set(handles.mass,'string',num2str(p.mass));
set(handles.I,'string',num2str(p.I));
set(handles.rho_air,'string',num2str(p.rho_air));
set(handles.rho_water,'string',num2str(p.rho_water));
set(handles.sailType,'value',p.sailType);
set(handles.angle_sRelb,'string',num2str(p.angle_sRelb));
set(handles.angle_sRelw,'string',num2str(p.angle_sRelw));
set(handles.SA_sail,'string',num2str(p.SA_sail));
set(handles.d_sail,'string',num2str(p.d_sail));
set(handles.SA_keel,'string',num2str(p.SA_keel));
set(handles.d_keel,'string',num2str(p.d_keel));
set(handles.rudderType,'value',p.rudderType);
set(handles.SA_rudder,'string',num2str(p.SA_rudder));
set(handles.angle_rRelb,'string',num2str(p.angle_rRelb));
set(handles.angle_rRels,'string',num2str(p.angle_rRels));
set(handles.d_rudder,'string',num2str(p.d_rudder));
set(handles.d_rRels,'string',num2str(p.d_rRels));
set(handles.time,'string',num2str(p.time));
set(handles.fps,'string',num2str(p.fps));
set(handles.view,'value',p.view);
set(handles.accuracy,'value',p.accuracy);
set(handles.active,'value',p.active);

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes sailsimGUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = sailsimGUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function x0_Callback(hObject, eventdata, handles)
% hObject    handle to x0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of x0 as text
%        str2double(get(hObject,'String')) returns contents of x0 as a double


% --- Executes during object creation, after setting all properties.
function x0_CreateFcn(hObject, eventdata, handles)
% hObject    handle to x0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function y0_Callback(hObject, eventdata, handles)
% hObject    handle to y0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of y0 as text
%        str2double(get(hObject,'String')) returns contents of y0 as a double


% --- Executes during object creation, after setting all properties.
function y0_CreateFcn(hObject, eventdata, handles)
% hObject    handle to y0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function theta0_Callback(hObject, eventdata, handles)
% hObject    handle to theta0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of theta0 as text
%        str2double(get(hObject,'String')) returns contents of theta0 as a double


% --- Executes during object creation, after setting all properties.
function theta0_CreateFcn(hObject, eventdata, handles)
% hObject    handle to theta0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function xdot0_Callback(hObject, eventdata, handles)
% hObject    handle to xdot0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of xdot0 as text
%        str2double(get(hObject,'String')) returns contents of xdot0 as a double


% --- Executes during object creation, after setting all properties.
function xdot0_CreateFcn(hObject, eventdata, handles)
% hObject    handle to xdot0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ydot0_Callback(hObject, eventdata, handles)
% hObject    handle to ydot0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ydot0 as text
%        str2double(get(hObject,'String')) returns contents of ydot0 as a double


% --- Executes during object creation, after setting all properties.
function ydot0_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ydot0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function thetadot0_Callback(hObject, eventdata, handles)
% hObject    handle to thetadot0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of thetadot0 as text
%        str2double(get(hObject,'String')) returns contents of thetadot0 as a double


% --- Executes during object creation, after setting all properties.
function thetadot0_CreateFcn(hObject, eventdata, handles)
% hObject    handle to thetadot0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function v_airMag_Callback(hObject, eventdata, handles)
% hObject    handle to v_airMag (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of v_airMag as text
%        str2double(get(hObject,'String')) returns contents of v_airMag as a double


% --- Executes during object creation, after setting all properties.
function v_airMag_CreateFcn(hObject, eventdata, handles)
% hObject    handle to v_airMag (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function rho_water_Callback(hObject, eventdata, handles)
% hObject    handle to rho_water (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of rho_water as text
%        str2double(get(hObject,'String')) returns contents of rho_water as a double


% --- Executes during object creation, after setting all properties.
function rho_water_CreateFcn(hObject, eventdata, handles)
% hObject    handle to rho_water (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function v_airAngle_Callback(hObject, eventdata, handles)
% hObject    handle to v_airAngle (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of v_airAngle as text
%        str2double(get(hObject,'String')) returns contents of v_airAngle as a double


% --- Executes during object creation, after setting all properties.
function v_airAngle_CreateFcn(hObject, eventdata, handles)
% hObject    handle to v_airAngle (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function mass_Callback(hObject, eventdata, handles)
% hObject    handle to mass (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of mass as text
%        str2double(get(hObject,'String')) returns contents of mass as a double


% --- Executes during object creation, after setting all properties.
function mass_CreateFcn(hObject, eventdata, handles)
% hObject    handle to mass (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function rho_air_Callback(hObject, eventdata, handles)
% hObject    handle to rho_air (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of rho_air as text
%        str2double(get(hObject,'String')) returns contents of rho_air as a double


% --- Executes during object creation, after setting all properties.
function rho_air_CreateFcn(hObject, eventdata, handles)
% hObject    handle to rho_air (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function I_Callback(hObject, eventdata, handles)
% hObject    handle to I (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of I as text
%        str2double(get(hObject,'String')) returns contents of I as a double


% --- Executes during object creation, after setting all properties.
function I_CreateFcn(hObject, eventdata, handles)
% hObject    handle to I (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in start.
function start_Callback(hObject, eventdata, handles)
% hObject    handle to start (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%%%simulates sailboat as keel, hull, & rudder (all airfoils) in 2D

[p,z0]=setBoatParam;

%parameters
z0(1)=str2double(get(handles.x0,'string'));
z0(2)=str2double(get(handles.y0,'string'));
z0(3)=str2double(get(handles.theta0,'string'));
z0(4)=str2double(get(handles.xdot0,'string'));
z0(5)=str2double(get(handles.ydot0,'string'));
z0(6)=str2double(get(handles.thetadot0,'string'));
p.v_airMag=str2double(get(handles.v_airMag,'string'));
p.v_airAngle=str2double(get(handles.v_airAngle,'string'));
p.mass=str2double(get(handles.mass,'string'));
p.I=str2double(get(handles.I,'string'));
p.rho_air=str2double(get(handles.rho_air,'string'));
p.rho_water=str2double(get(handles.rho_water,'string'));
p.sailType=get(handles.sailType,'value');
p.angle_sRelb=str2double(get(handles.angle_sRelb,'string'));
p.angle_sRelw=str2double(get(handles.angle_sRelw,'string'));
p.SA_sail=str2double(get(handles.SA_sail,'string'));
p.d_sail=str2double(get(handles.d_sail,'string'));
p.SA_keel=str2double(get(handles.SA_keel,'string'));
p.d_keel=str2double(get(handles.d_keel,'string'));
p.rudderType=get(handles.rudderType,'value');
p.SA_rudder=str2double(get(handles.SA_rudder,'string'));
p.angle_rRelb=str2double(get(handles.angle_rRelb,'string'));
p.angle_rRels=str2double(get(handles.angle_rRels,'string'));
p.d_rudder=str2double(get(handles.d_rudder,'string'));
p.d_rRels=str2double(get(handles.d_rRels,'string'));
p.time=str2double(get(handles.time,'string'));
p.fps=str2double(get(handles.fps,'string'));
p.view=get(handles.view,'value');
p.accuracy=get(handles.accuracy,'value');
p.active=get(handles.active,'value');

p.tspan=linspace(0,p.time,p.time*p.fps);
p.v_a=p.v_airMag*[cos(p.v_airAngle),sin(p.v_airAngle)]; %x-y velocity componenets of air [m/s]

if p.active>1
    [t,zarray]=odeEuler(@rhs,[0,1000],z0,p);
else
    %accuracy of numerical solution
    options=odeset('abstol',1e-4,'reltol',1e-4);
    h=waitbar(0,'Sailing...');
    %heart of program
    [t,zarray]=ode23(@rhs,p.tspan,z0,options,p);
    close(h);
    %animate results
    animate(t,zarray,p)
end

function time_Callback(hObject, eventdata, handles)
% hObject    handle to time (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of time as text
%        str2double(get(hObject,'String')) returns contents of time as a double


% --- Executes during object creation, after setting all properties.
function time_CreateFcn(hObject, eventdata, handles)
% hObject    handle to time (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function fps_Callback(hObject, eventdata, handles)
% hObject    handle to fps (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of fps as text
%        str2double(get(hObject,'String')) returns contents of fps as a double


% --- Executes during object creation, after setting all properties.
function fps_CreateFcn(hObject, eventdata, handles)
% hObject    handle to fps (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function d_rudder_Callback(hObject, eventdata, handles)
% hObject    handle to d_rudder (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of d_rudder as text
%        str2double(get(hObject,'String')) returns contents of d_rudder as a double


% --- Executes during object creation, after setting all properties.
function d_rudder_CreateFcn(hObject, eventdata, handles)
% hObject    handle to d_rudder (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function SA_rudder_Callback(hObject, eventdata, handles)
% hObject    handle to SA_rudder (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of SA_rudder as text
%        str2double(get(hObject,'String')) returns contents of SA_rudder as a double


% --- Executes during object creation, after setting all properties.
function SA_rudder_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SA_rudder (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function angle_rRelb_Callback(hObject, eventdata, handles)
% hObject    handle to angle_rRelb (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of angle_rRelb as text
%        str2double(get(hObject,'String')) returns contents of angle_rRelb as a double


% --- Executes during object creation, after setting all properties.
function angle_rRelb_CreateFcn(hObject, eventdata, handles)
% hObject    handle to angle_rRelb (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function d_keel_Callback(hObject, eventdata, handles)
% hObject    handle to d_keel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of d_keel as text
%        str2double(get(hObject,'String')) returns contents of d_keel as a double


% --- Executes during object creation, after setting all properties.
function d_keel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to d_keel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function SA_keel_Callback(hObject, eventdata, handles)
% hObject    handle to SA_keel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of SA_keel as text
%        str2double(get(hObject,'String')) returns contents of SA_keel as a double


% --- Executes during object creation, after setting all properties.
function SA_keel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SA_keel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function d_sail_Callback(hObject, eventdata, handles)
% hObject    handle to d_sail (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of d_sail as text
%        str2double(get(hObject,'String')) returns contents of d_sail as a double


% --- Executes during object creation, after setting all properties.
function d_sail_CreateFcn(hObject, eventdata, handles)
% hObject    handle to d_sail (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function angle_sRelw_Callback(hObject, eventdata, handles)
% hObject    handle to angle_sRelw (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of angle_sRelw as text
%        str2double(get(hObject,'String')) returns contents of angle_sRelw as a double


% --- Executes during object creation, after setting all properties.
function angle_sRelw_CreateFcn(hObject, eventdata, handles)
% hObject    handle to angle_sRelw (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function SA_sail_Callback(hObject, eventdata, handles)
% hObject    handle to SA_sail (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of SA_sail as text
%        str2double(get(hObject,'String')) returns contents of SA_sail as a double


% --- Executes during object creation, after setting all properties.
function SA_sail_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SA_sail (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in fixedSail.
function fixedSail_Callback(hObject, eventdata, handles)
% hObject    handle to fixedSail (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of fixedSail


% --- Executes on button press in freeSail.
function freeSail_Callback(hObject, eventdata, handles)
% hObject    handle to freeSail (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of freeSail



function angle_sRelb_Callback(hObject, eventdata, handles)
% hObject    handle to angle_sRelb (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of angle_sRelb as text
%        str2double(get(hObject,'String')) returns contents of angle_sRelb as a double


% --- Executes during object creation, after setting all properties.
function angle_sRelb_CreateFcn(hObject, eventdata, handles)
% hObject    handle to angle_sRelb (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in waterRudder.
function waterRudder_Callback(hObject, eventdata, handles)
% hObject    handle to waterRudder (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of waterRudder


% --- Executes on button press in airRudder.
function airRudder_Callback(hObject, eventdata, handles)
% hObject    handle to airRudder (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of airRudder


% --- Executes on selection change in accuracy.
function accuracy_Callback(hObject, eventdata, handles)
% hObject    handle to accuracy (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns accuracy contents as cell array
%        contents{get(hObject,'Value')} returns selected item from accuracy


% --- Executes during object creation, after setting all properties.
function accuracy_CreateFcn(hObject, eventdata, handles)
% hObject    handle to accuracy (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in rudderType.
function rudderType_Callback(hObject, eventdata, handles)
% hObject    handle to rudderType (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns rudderType contents as cell array
%        contents{get(hObject,'Value')} returns selected item from rudderType


% --- Executes during object creation, after setting all properties.
function rudderType_CreateFcn(hObject, eventdata, handles)
% hObject    handle to rudderType (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in sailType.
function sailType_Callback(hObject, eventdata, handles)
% hObject    handle to sailType (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns sailType contents as cell array
%        contents{get(hObject,'Value')} returns selected item from sailType


% --- Executes during object creation, after setting all properties.
function sailType_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sailType (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function d_rRels_Callback(hObject, eventdata, handles)
% hObject    handle to d_rRels (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of d_rRels as text
%        str2double(get(hObject,'String')) returns contents of d_rRels as a double


% --- Executes during object creation, after setting all properties.
function d_rRels_CreateFcn(hObject, eventdata, handles)
% hObject    handle to d_rRels (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function angle_rRels_Callback(hObject, eventdata, handles)
% hObject    handle to angle_rRels (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of angle_rRels as text
%        str2double(get(hObject,'String')) returns contents of angle_rRels as a double


% --- Executes during object creation, after setting all properties.
function angle_rRels_CreateFcn(hObject, eventdata, handles)
% hObject    handle to angle_rRels (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in view.
function view_Callback(hObject, eventdata, handles)
% hObject    handle to view (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns view contents as cell array
%        contents{get(hObject,'Value')} returns selected item from view


% --- Executes during object creation, after setting all properties.
function view_CreateFcn(hObject, eventdata, handles)
% hObject    handle to view (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in active_rudder.
function active_rudder_Callback(hObject, eventdata, handles)
% hObject    handle to active_rudder (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of active_rudder


% --- Executes on selection change in active.
function active_Callback(hObject, eventdata, handles)
% hObject    handle to active (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns active contents as cell array
%        contents{get(hObject,'Value')} returns selected item from active


% --- Executes during object creation, after setting all properties.
function active_CreateFcn(hObject, eventdata, handles)
% hObject    handle to active (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
