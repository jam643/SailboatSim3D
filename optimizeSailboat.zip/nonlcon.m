function [c,ceq]=nonlcon(guess,p)
%use boat EOM of steady state motion as constraints 

%% unpack variables
% updated parameters
p.rudder.angle_relSail=guess(6);
p.sail.angle_relBody=guess(7);
p.sail.length=guess(8);
p.sail.width=guess(9);
p.rudder.length=guess(10);
p.rudder.width=guess(11);
p.rudder.origin_relSail(1)=guess(12);
p.keel.length=guess(13);
p.keel.width=guess(14);
% updated boat state
boat_COM=[0;0;guess(1)];
boat_angles=[guess(2);0;guess(3)];
v_boat_relFixed=[guess(4:5);0];
w_boat_relBody=zeros(3,1);
state=[boat_COM;boat_angles;v_boat_relFixed;w_boat_relBody];

%% update COM, Moment of inertia values
p=boatGeometry(p,state);

%% calculate forces and moments on airfoils (sail, keel, and rudder)
% net force and moment on sail
[netForce_sail_relFixed, netMoment_sail_relBody] = airfoil_forces2(state,p.sail,p);
% net force and moment on keel
[netForce_keel_relFixed, netMoment_keel_relBody] = airfoil_forces2(state,p.keel,p);
% net force and moment on rudder
[netForce_rudder_relFixed, netMoment_rudder_relBody] = airfoil_forces2(state,p.rudder,p);

%% calculate hull forces and moments
% net force in xy plane and moment in z direction caused by hull
[xyForce_hull_relFixed,zMoment_hull_relBody]=hullForce_xy(p.boat.Rt,v_boat_relFixed,boat_angles(3),w_boat_relBody,p);
% net force in z direction and moment in x direction caused by hull
[zForce_hull_relFixed,xMoment_hull_relBody]=hullForce_yz(p.boat.R,p.boat.Rt,p.hull,v_boat_relFixed,boat_COM(3),p);

%% Calculate weight
Force_weight_relFixed=[0,0,-p.g*p.boat.mass]';

%% Linear Momentum Balance (a=F/m)
vdot=(netForce_sail_relFixed+netForce_keel_relFixed+netForce_rudder_relFixed+...
    xyForce_hull_relFixed+zForce_hull_relFixed+Force_weight_relFixed)...
    /p.boat.mass;

%% Angular Momentum Balance
% yaw angular acceleration
psidotdot=dot((netMoment_sail_relBody+netMoment_keel_relBody+...
    netMoment_rudder_relBody+zMoment_hull_relBody),[0;0;1])/p.boat.Izz;
% roll angular acceleration
phidotdot=dot((netMoment_sail_relBody+netMoment_keel_relBody+...
    netMoment_rudder_relBody+xMoment_hull_relBody),[1;0;0])/p.boat.Ixx;

% [LD_efficiency_sail] = airfoil_efficiency(state,p.sail,p);
% [LD_efficiency_keel] = airfoil_efficiency(state,p.keel,p);
% [LD_efficiency_rudder] = airfoil_efficiency(state,p.rudder,p);

ceq=[vdot;psidotdot;phidotdot];
c=[p.boat.mass-6;0.1-p.hull.origin(3);...
    2*p.sail.SA*(p.sail.width+p.keel.width)/4-abs(p.rudder.SA*p.rudder.origin_relSail(1))];