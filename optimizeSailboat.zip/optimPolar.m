function optimPolar()

%% add path to sailSim
addpath('C:\Users\Jesse\Documents\Cornell\M.Eng 2nd\CUSail Research\3DsailSim_old')

% filename='polarData_2mps.csv';

%% get boat parameters
[p,state0]=setBoatParam('boat1');

delta_theta=5;
theta=125:-delta_theta:0;

v_mag=zeros(length(theta),1);
theta_result=zeros(length(theta),1);
rudder_angle=zeros(length(theta),1);
sail_angle=zeros(length(theta),1);

for i=1:length(theta)
    
    %% Initial guess values and bounds
    % state of boat [guess,lowerBound,upperBound]
    z0=[state0(3),-1,1]; % z coordinates of boat COM
    phi0=[0,-pi/2,pi/2]; % roll of boat
    psi0=[theta(i)*pi/180,(theta(i)-20)*pi/180,(theta(i)+20)*pi/180]; % yaw of boat
    v_mag_guess=[0.5,0,5];
    v_theta_guess=pi/180*[theta(i),theta(i),theta(i)];
    stateInit=[z0;phi0;psi0;v_mag_guess;v_theta_guess];
    % parameters to be optimized [guess,lowerBound,upperBound]
    rudder_angle0=[12,0,20]*pi/180;
    sail_angle0=[180-theta(i)-20,180-theta(i)-40,180-theta(i)]*pi/180;
    paramsInit=[rudder_angle0;sail_angle0];
    %guess value
    guess=[stateInit(:,1);paramsInit(:,1)];
    %lower bound
    lowerBound=[stateInit(:,2);paramsInit(:,2)];
    %upper bound
    upperBound=[stateInit(:,3);paramsInit(:,3)];
    
    %% Function Arguments
    %cost function
    costFun = @(guess)costFun_maxPolar(guess,p);
    %nonlinear constrain fn
    constraintFun = @(guess)nonlconPolar(guess,p);
    
    %% call FMINCON
    options = optimset('Algorithm','interior-point','TolFun',1e-9);
    [result,~,exitFlag] = fmincon(costFun,guess,[],[],[],[],lowerBound,upperBound,...
        constraintFun,options)
    
    %% update parameters and state to match optimized values
    state0=zeros(12,1);
    state0(3)=result(1);
    state0(4)=result(2);
    state0(6)=result(3);
    velocity_unitVect=[cos(result(5));sin(result(5))];
    state0(7)=velocity_unitVect(1)*result(4);
    state0(8)=velocity_unitVect(2)*result(4);
    p.rudder.angle_relSail=result(6);
    p.sail.angle_relBody=result(7);
    
    if exitFlag == 0
        v_mag(i)=0;
    else
        v_mag(i)=result(4);
    end
    theta_result(i)=result(5);
    rudder_angle(i)=result(6);
    sail_angle(i)=result(7);
   
    %% run real-time simulation based on optimized parameters
    p.realTime=1;
    [tarray,stateArray]=odeEuler(@rhs,state0,p);
end

%write to file
data=[round(180-theta_result*180/pi),round(v_mag*100)/100,round(sail_angle*180/pi),round(rudder_angle*180/pi)];

headers={'angle into wind','velocity mag. m/s','sail angle','tail angle'};
% csvwrite_with_headers(filename,data,headers)

h1=polar(pi-theta_result,v_mag);
hold on
h2=polar(pi+theta_result,v_mag);
% title('Polar Diagram for True Wind = 10m/s','fontsize',16);
set(h1,'color','k','linestyle','-','linewidth',3)
set(h2,'color','k','linestyle','-','linewidth',3)
view([-90 90])

