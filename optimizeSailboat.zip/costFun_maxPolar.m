function v_mag=costFun_maxPolar(guess,p)

v_mag=-guess(4);