function v_madeGood=costFun_maxVMG(guess,p)
% maximize VMG
v_boat_relFixed=[guess(4:5);0];
wind_unitVect=p.v_air_relFixed/norm(p.v_air_relFixed);
v_madeGood=dot(v_boat_relFixed,wind_unitVect);