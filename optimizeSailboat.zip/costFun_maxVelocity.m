function v_magnitude=costFun_maxVelocity(guess,p)
% maximize VMG
v_boat_relFixed=[guess(4:5);0];
v_magnitude=-norm(v_boat_relFixed);