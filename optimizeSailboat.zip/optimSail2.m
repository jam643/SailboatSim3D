function optimSail2()

%% add path to sailSim
addpath('C:\Users\Jesse\Documents\Cornell\M.Eng 2nd\CUSail Research\3DsailSim_old')

%% get boat parameters
[p,state0]=setBoatParam('boat1');

%% Initial guess values and bounds
% parameters to be optimized [guess,lowerBound,upperBound]
rudder_angle0=[15*pi/180,-pi,pi];
sail_angle0=[25*pi/180,-pi,pi];
sail_length0=[p.sail.length,0,1];
sail_width0=[p.sail.width,0,1];
rudder_length0=[p.rudder.length,0,2];
rudder_width0=[p.rudder.width,0,1];
rudder_relSail0=[p.rudder.origin_relSail(1),-0.4,0];
keel_length0=[p.keel.length,0,2];
keel_width0=[p.keel.width,0.04,0.5];
paramsInit=[rudder_angle0;sail_angle0;sail_length0;sail_width0;...
    rudder_length0;rudder_width0;rudder_relSail0;keel_length0;...
    keel_width0];
% state of boat [guess,lowerBound,upperBound]
z0=[state0(3),-1,1]; % z coordinates of boat COM
phi0=[0,-pi/20,pi/20]; % roll of boat
psi0=[120*pi/180,-2*pi,2*pi]; % yaw of boat
v_mag_guess=[0.5,0,5];
v_theta_guess=[120,120,120]*pi/180;
stateInit=[z0;phi0;psi0;v_mag_guess;v_theta_guess];
%guess value
guess=[stateInit(:,1);paramsInit(:,1)];
%lower bound
lowerBound=[stateInit(:,2);paramsInit(:,2)];
%upper bound
upperBound=[stateInit(:,3);paramsInit(:,3)];

%% linear inequality constraint
A=[zeros(1,7),1,zeros(1,4),1,0;...
    zeros(1,8),0.5,0,0.5,1,0,0;...
    zeros(1,7),-0.25,0,1,zeros(1,4)];
b=[2-abs(p.keel.origin(3))-abs(p.sail.origin(3));...
    0;0];

%% Function Arguments
%cost function
costFun = @(guess)costFun_maxPolar(guess,p);
%nonlinear constrain fn
constraintFun = @(guess)nonlcon2(guess,p);

%% call FMINCON
options = optimset('Algorithm','interior-point','TolFun',1e-9);
result = fmincon(costFun,guess,A,b,[],[],lowerBound,upperBound,...
    constraintFun,options)

%% update parameters and state to match optimized values
state0=zeros(12,1);
state0(3)=result(1);
state0(4)=result(2);
state0(6)=result(3);
velocity_unitVect=[cos(result(5));sin(result(5))];
state0(7)=velocity_unitVect(1)*result(4);
state0(8)=velocity_unitVect(2)*result(4);
p.rudder.angle_relSail=result(6);
p.sail.angle_relBody=result(7);
p.sail.length=result(8);
p.sail.width=result(9);
p.rudder.length=result(10);
p.rudder.width=result(11);
p.rudder.origin_relSail(1)=result(12);
p.keel.length=result(13);
p.keel.width=result(14);

%% run real-time simulation based on optimized parameters
p.realTime=1;
[tarray,stateArray]=odeEuler(@rhs,state0,p);

p.realTime=0;
%set accuracy of ode solver
options=odeset('abstol',1e-4,'reltol',1e-4);
%initialize loading bar
p.waitBar=waitbar(0,'Sailing...');
%numerically solve for boat trajectory
[tarray,stateArray]=ode23(@rhs,p.tspan,state0,options,p);
%close the loading bar
close(p.waitBar);
%animate the resulting trajectory
animate(tarray,stateArray,p)

